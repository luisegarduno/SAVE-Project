//
// Created By Luis Garduno || Southern Methodist University : 2021-09-04
//

#include <iostream>
#include "Start.h"

int main(){

     Start run;

     run.rule_1();
     run.rule_2();

     return 0;
}